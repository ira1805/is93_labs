﻿using System;

namespace laba1
{
    class Program
    {
        public static void Increase(ref int x)
        {
            int bit = 1, counter = 0;
            while (bit != 0)
            {
                bit = (x >> counter) & 1;
                x ^= 1 << counter;
                counter++;
            }
        }

        public static int Compare(int a, int b)
        {
            int bitA = (a >> 15) & 1, bitB = (b >> 15) & 1;
            for (int i = 15; i >= 0; i--)
            {
                bitA = (a >> i) & 1;
                bitB = (b >> i) & 1;
                if (bitA != bitB)
                    return 0;
            }
            return 1;
        }
        static void Main()
        {
            int a = 15, b = 15, c = 15;
            Increase(ref a);
            Console.WriteLine(a);
            Console.WriteLine();
            Console.WriteLine(Compare(b, c));
            Console.ReadKey();
        }
    }
}
